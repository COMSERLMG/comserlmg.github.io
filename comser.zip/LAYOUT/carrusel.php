  <div class="slider">
    <div class="slides">
      <img src="./IMG/CARRUSEL IMAGENES/img1.png" alt="IMG1">
      <img src="./IMG/CARRUSEL IMAGENES/img2.png" alt="IMG2">
      <img src="./IMG/CARRUSEL IMAGENES/img3.png" alt="IMG3">
    </div>
    <button class="prev" onclick="prevSlide()">&#10094</button>
    <button class="next" onclick="nextSlide()">&#10095</button>
  </div>