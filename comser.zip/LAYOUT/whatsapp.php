<div class="wasap">
    <a href="https://api.whatsapp.com/send?phone=51989932171&text=Hola%21%20Quisiera%20m%C3%A1s%20informaci%C3%B3n%20."
        class="float" target="_blank">
        <i class="fa fa-whatsapp my-float"></i>
        <img src="./IMG/LOGOS OTRAS EMPRESAS/whatsapp.svg" alt="wsp" width="40">

    </a>
</div>