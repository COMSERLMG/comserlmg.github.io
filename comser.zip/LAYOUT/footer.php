<footer>
    <div class="footer">
      <div class="foot-start">
        <div class="logofoot">
          <img src="./IMG/LOGOS COMSER LMG/horizontal invert.svg" alt="logo" width="340">
        </div>
        <div class="infofoot">
          <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Ab officia mollitia ex! Repellat beatae ex odit
            sit
            architecto labore, esse atque expedita mollitia nemo minima amet consequuntur voluptatum omnis nostrum.</p>
        </div>
      </div>


      <div class="stfoot">
        <h1>PRODUCTOS</h1>
        <div>
          <a href="#">Link</a>
          <a href="#">Link</a>
          <a href="#">Link</a>
          <a href="#">Link</a>
        </div>
      </div>

      <div class="stfoot">
        <h1>SERVICIOS</h1>
        <div>
          <a href="#">Link</a>
          <a href="#">Link</a>
          <a href="#">Link</a>
          <a href="#">Link</a>
        </div>
      </div>
      <div class="stfoot">
        <h1>CATALGOGOS</h1>
        <div>
          <a href="#">Link</a>
          <a href="#">Link</a>
          <a href="#">Link</a>
          <a href="#">Link</a>
        </div>
      </div>
      <div class="foot-end">
        <div class="foot-button">
          <a href="#">CONTACTANOS</a>
        </div>
        <div class="foot-button">
          <a href="#">ENCUENTRANOS</a>
        </div>
        <div class="foot-button">
          <a href="#">SIGUENOS</a>
        </div>

      </div>
    </div>
    <div class="info-footer">
      <h1>Componentes y Servicios Eléctricos, COMSER LMG S.A.C. </h1>
    </div>



  </footer>